(function($, task) {
"use strict";

function Events9() { // ps.details.search_texts 

	function on_view_form_created(item) {
		//item.view_form.find("#new-btn").hide();
		item.view_form.find("#edit-btn").hide();
		//item.view_form.find("#delete-btn").hide();
		//item.table_options.multiselect = false;
	
	   // if (!item.lookup_field) {
			var search_add_btn = item.add_view_button('További keresés', {image: 'icon-pencil'});
			search_add_btn.click(function() {search_add(item)});
			var new_search_btn = item.add_view_button('Új keresés', {image: 'icon-pencil'});
			new_search_btn.click(function() {new_search(item) });
			//item.table_options.multiselect = true;
		//}
	} 
	
	function new_search(item) {
		//console.log('on_view_form_created!');
		//var selections = item.selections;
		//onsole.log(item.search_text.value)//****---------------------
		//if (selections.length==0) console.log(item.search_text.value) 
	   // else console.log(selections[0]);	
		yes_no(item,"Az összes eddigi megtalált termék törlődni fog a Találat táblából. Biztosan folytatja?", function(){task.search_texts.server('main', [item.search_text.value, true]);item.refresh_page()});
	}
	
	function search_add(item) {
		yes_no(item,"A találatok táblába a most megadott termékek is bekerülnek. Biztosan folytatja?", function(){task.search_texts.server('main', [item.search_text.value, false]);item.refresh_page()});
	}
	
	function yes_no(item, mess, yesCallback, noCallback) {
		var buttons = {
			Igen: yesCallback,
			Nem: noCallback,
			//Cancel: cancelCallback
		};
		item.message(mess, {buttons: buttons, margin: "20px",
			text_center: true, width: 500, center_buttons: true});
	}
	this.on_view_form_created = on_view_form_created;
	this.new_search = new_search;
	this.search_add = search_add;
	this.yes_no = yes_no;
}

task.events.events9 = new Events9();

})(jQuery, task)